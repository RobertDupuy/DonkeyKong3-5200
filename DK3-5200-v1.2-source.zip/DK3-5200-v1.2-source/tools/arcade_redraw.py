"""Adapt the original arcade bodies to the Atari's 2:1 pixel grid.

No vertical resampling, replacement faces, stretched players, or invented
animation poses. Red details become fur, as in the reviewed artwork study.
The two eyes receive an explicit native-grid transcription so both pupils
survive horizontal reduction; all other features come from the source crop.
"""
from pathlib import Path
import hashlib, json, struct
from PIL import Image

R=Path(__file__).resolve().parents[1]
A=R/'src/kong'
manifest=json.loads((A/'arcade/manifest.json').read_text())
proposal=json.loads((A/'proposal-manifest.json').read_text())
metadata=(A/'body-frame-metadata.bin').read_bytes()
roles={(0,0,0,0):0,(102,40,7,255):1,(240,60,51,255):1,
       (246,150,103,255):3,(255,255,255,255):4}

def white_components(a):
    pending={(x,y) for y,row in enumerate(a) for x,v in enumerate(row) if v==4}
    out=[]
    while pending:
        start=pending.pop(); todo=[start]; points={start}
        while todo:
            x,y=todo.pop()
            for p in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
                if p in pending:pending.remove(p);points.add(p);todo.append(p)
        out.append(points)
    return out

def build():
    bodies=[]
    for i,entry in enumerate(manifest['arcade_bodies']):
        path=A/'arcade'/Path(entry['file']).name
        im=Image.open(path).convert('RGBA')
        source_pos=proposal['body_frames'][i]['source_pos']
        crop_pos=list(entry['first']['position'])
        # The M060 catalogue's first observation stores the composite origin,
        # including a detached hive. Its 48-pixel body fills all three sprite
        # columns, whose original hardware X positions give the body origin.
        if entry['id']=='M060':
            raw=bytes.fromhex(entry['first']['shadow'])
            assert im.width==48
            crop_pos[0]=min(raw[o]-23 for o in range(0x18,0x30,4))
        height=struct.unpack_from('<HBB',metadata,i*4)[1]
        dx=crop_pos[0]-source_pos[0];dy=crop_pos[1]-source_pos[1]
        assert 0<=dx and 0<=dy and dx+im.width<=48 and dy+im.height<=height,entry['id']
        canvas=Image.new('RGBA',(48,height))
        canvas.paste(im,(crop_pos[0]-source_pos[0],crop_pos[1]-source_pos[1]))
        a=[[roles[canvas.getpixel((x,y))] for x in range(48)] for y in range(height)]
        native=[]
        for row in a:
            line=[]
            for x in range(0,48,2):
                pair=row[x:x+2]
                if 4 in pair:v=4
                elif 1 in pair:v=1
                elif 3 in pair:v=3
                else:v=0
                line.append(v)
            native.append(line)
        # Locate the two original white eye islands, never a pose-number face
        # replacement. Translate their height, gaze and vertical pupil position.
        islands=[]
        for points in white_components(a):
            xs=[p[0] for p in points];ys=[p[1] for p in points]
            box=(min(xs),min(ys),max(xs),max(ys))
            if 2<=box[2]-box[0]+1<=4 and 3<=box[3]-box[1]+1<=6:
                islands.append((box,points))
        candidates=[]
        for b,p in islands:
            for c,q in islands:
                if b[0]<c[0] and 2<=c[0]-b[2]<=4 and b[1]==c[1] and b[3]==c[3]:
                    candidates.append((abs((b[0]+c[2])/2-24),b,c))
        eye_edit=None
        if candidates:
            _,b,c=min(candidates)
            left=round(((b[0]+c[2])/2-5)/2)
            top=b[1]; bottom=b[3]
            for y in range(top,bottom+1):
                pupil_left=any(a[y][x]==1 for x in range(b[0],b[2]+1))
                pupil_right=any(a[y][x]==1 for x in range(c[0],c[2]+1))
                native[y][left:left+5]=[4,1 if pupil_left else 4,3,1 if pupil_right else 4,4]
            eye_edit=dict(x=left,y=top,height=bottom-top+1)
        bodies.append(dict(body=i+1,source=entry['id'],source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           height=height,crop_position=crop_pos,eye_transcription=eye_edit,pixels=native))
    return bodies

if __name__=='__main__':
    bodies=build()
    (A/'arcade-native.json').write_text(json.dumps(bodies,separators=(',',':')))
    print('Arcade-derived native bodies:',len(bodies),'eye transcriptions:',sum(bool(b['eye_transcription']) for b in bodies))
