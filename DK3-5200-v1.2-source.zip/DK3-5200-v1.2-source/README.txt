DK3-5200 v0.2 — Atari 5200 port of DKFAST v0.3

v0.2 color correction
---------------------
The platform palette now starts exactly at bitmap row 134. The rows
immediately above the top trestle retain green vines and caterpillars. The display
list delays one DLI by five scanlines in each buffer; interrupt count and handler are unchanged. NTSC framebuffer comparisons
verify that only five rows above the platform change. Both screen buffers
and all three stage layouts pass. The revised six-round input route is
included because moving a raster interrupt changes instruction scheduling,
so the old v0.1 frame-by-frame input recording is not a valid golden replay.

Target and loading
------------------
Stock 16 KB Atari 5200, NTSC timing, controller port 1.
128 KB SuperCart banking (Atari800 cartridge type 72).

Use DK3-5200-v0.2.car with an emulator that supports this mapper. The CAR
header selects the mapper. DK3-5200-v0.2.rom contains the same cartridge
payload without a header. For a flash cart, explicitly select 128 KB 5200
SuperCart banking if the loader cannot identify a raw image. This is not a
standard unbanked 32 KB cartridge. The mapper matches the intended
A5200PicoCart SuperCart mode; physical compatibility has not been tested.

Controls
--------
Analog stick: left/right movement, up/down platform movement and jumping.
Lower fire button: pump spray; release and press again for another pump.
START: start a game from the title or game-over screen.
PAUSE: pause/resume.
RESET: return to the title.
Keypad 1: toggle music; sound effects remain enabled.
Analog thresholds are 80/150, with a central dead zone. Only port 1 is used.

What was ported
---------------
The DKFAST v0.3 gameplay, detailed native Kong artwork (124 poses), enemy and
projectile art, hit reactions, defeat/victory scenes, Super Spray, music,
score/HUD, and level progression are retained. Logic runs at nominal 30 Hz.
The console renderer has a different cost: the recorded six-round campaign
averaged 22.81 newly presented frames/second during active play, at nominal
60 Hz television timing. This is not a locked 30 or 60 fps rendering claim.

The main change is memory architecture. Both 6 KB bitmap buffers remain in
RAM. The old RAM scenery copy and graphics caches are replaced by immutable
ROM row dictionaries and banked native/compiled sprite data. One player/
missile buffer is updated in VBI, with the hives copied before the long Kong
poses. Common bank trampolines and interrupt code are duplicated in all
four 32 KB banks. Gameplay code executes in bank 0. GTIA/POKEY addresses,
BIOS interrupt vectors, diagnostic boot, analog inputs, keypad and reset
handling are specific to the console.

RAM map
-------
$0080-$00CC  Zero-page work and cc65 temporaries (77 bytes)
$0100-$01FF  6502 hardware stack
$0200-$0207  BIOS IRQ, VBI and DLI vectors
$0208-$02FF  C software stack space (grows down from $02FF)
$0300-$07FF  Single player/missile DMA area
$0800-$0DCC  Static game state (1477-byte BSS + 8-byte DATA)
$0DCD-$0FFF  563 bytes unallocated
$1000-$27FF  Bitmap 0 (6144 bytes)
$2800-$3FFF  Bitmap 1 (6144 bytes)

ROM map
-------
Four 32 KB banks mapped at $4000-$BFFF.
$4000-$B7FF  Main code/data in bank 0; assets in banks 1-3
$B800-$BFBF  Reserved common region, duplicated in every bank
$BFC0-$BFFF  Mapper register/tail region; diagnostic boot vectors at $BFFD

Code and constant data: 29,715 bytes. Assets: 85,489 bytes, including a
10,816-byte background row dictionary. Common code/data: 1,869 bytes per
bank, padded within a 1,984-byte reserved region. Total ROM: 131,072 bytes.
The build rejects code, common-region or asset-bank overflow.

Build
-----
Requires Python 3, Pillow, and cc65 (cc65, ca65, ld65 on PATH). Tested with
the Ubuntu cc65 2.19-1 package (compiler reports V2.18). Set CC65_HOME only if toolchain data cannot be located automatically;
it should contain include/, asminc/ and lib/none.lib.

    python3 -m pip install Pillow
    python3 port/build.py

Outputs appear in build/. The src/ directory preserves the inherited game
and its generated art inputs. port/prepare.py generates console sources in
build/port; port/assets.py adapts the bank allocator. Edit port/ for console
changes. tools/cart_assets.py and tools/arcade_redraw.py are inherited asset
generators used by this build. Other XL-only release tooling is omitted.

Validation
----------
Tests ran with a locally instrumented Atari800 7.2.0 core, cycle-exact ANTIC,
NTSC and its built-in Altirra 5200 BIOS. No physical console, analog joystick,
original Atari BIOS or flash cartridge was available for validation.

Passed:
* 32 cold starts: four initial banks and eight RAM randomization patterns.
* START, analog directions, PAUSE, keypad music, and 20 RESET/restart cycles.
* 18 defeat fixtures across three layouts, both defeat triggers, and three
  player positions; all defeat poses and exactly one life deduction.
* Protected four-note Super Spray pickup cue with music enabled and muted.
* Startup of all 99 supported rounds.
* Six before/after palette comparisons (three layouts, two buffers).
* 248 complete bitmap comparisons covering all 124 Kong poses/both buffers,
  plus 32 crowded overlap fixtures across all horizontal phases.
* 372 independent Kong player/missile plane comparisons.
* An input-only six-round campaign, followed by exact recorded-input replay,
  ending with two lives remaining. This route collects Super Spray.
* No writes to cartridge data or missed monitored player DMA deadlines in
  the final pixel, focused regression and six-round replay checks.

The focused startup/controls/defeat/audio/round suite contains 268 assertions.
validation5200/ contains current results and the reproducible input route.
Ordinary-spray-only bot attempts cleared up to four consecutive rounds, but
an entire six-round ordinary-only run has not been demonstrated on this port.
A direct simulation-equivalence experiment against the XL build was not
completed; it is not claimed as passing evidence.

To rebuild the emulator harness, obtain Atari800 7.2.0 separately, configure
its libatari800 target, enable NEW_CYCLE_EXACT, MONITOR_PROFILE and
MONITOR_BREAK in src/config.h, then run:

    python3 tests/patch_atari800.py /path/to/atari800/src
    make -C /path/to/atari800/src libatari800.a
    ATARI800_SOURCE=/path/to/atari800/src python3 tests5200/build.py
    python3 tests5200/regression.py
    python3 tests5200/pixels.py
    python3 tests5200/pm_pixels.py
    python3 tests5200/replay.py
    python3 tests5200/palette_boundary.py

The write-observer instrumentation is test-only. No instrumented emulator
binary or external BIOS is included. Tests use explicit RAM fixtures except
campaign.py and replay.py, which supply only controller input.

Hardware references
-------------------
Mapper: https://github.com/atari800/atari800/blob/master/DOC/cart.txt
5200 conversion notes:
https://atarimuseum.ctrl-alt-rees.com/videogames/consoles/5200/conv_to_5200.html

See CREDITS.txt for original game and music attribution.
