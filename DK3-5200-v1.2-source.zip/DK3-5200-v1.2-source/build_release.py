#!/usr/bin/env python3
"""Rebuild DK3-5200 v0.2 and reproduce the released V1.2 display-only patch."""
from pathlib import Path
import argparse
import hashlib
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE_SHA256 = "fb34555901fe5eb4e5e9a3fd00b7a44ea73325d7b68dcd7be9ea46d2565b1bb2"
RELEASE_SHA256 = "b42cf703d99eb0b614918076e8b9cf6ca22b75686e65ee18ffb7034082714454"


def release_car(original):
    if hashlib.sha256(original).hexdigest() != BASE_SHA256:
        raise ValueError("Input does not match the released DK3-5200 v0.2 CAR")
    result = bytearray(original)
    if result[0x3BA4] != 0x10:
        raise ValueError("Unexpected version character")
    result[0x3BA4] = 0x11
    result[8:12] = struct.pack(">I", sum(result[16:]) & 0xFFFFFFFF)
    if hashlib.sha256(result).hexdigest() != RELEASE_SHA256:
        raise ValueError("Output does not match the released DK3-5200 v1.2 CAR")
    return bytes(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-car", type=Path,
                        help="Use the exact released v0.2 CAR instead of compiling")
    args = parser.parse_args()
    if args.from_car is None:
        subprocess.run([sys.executable, str(ROOT / "port/build.py")],
                       cwd=ROOT, check=True)
        original = ROOT / "build/DK3-5200-v0.2.car"
    else:
        original = args.from_car
    car = release_car(original.read_bytes())
    target = ROOT / "build"
    target.mkdir(exist_ok=True)
    for filename, data in [("DK3-5200-v1.2.car", car),
                           ("DK3-5200-v1.2.rom", car[16:])]:
        path = target / filename
        path.write_bytes(data)
        print(f"{hashlib.sha256(data).hexdigest()}  {path}")


if __name__ == "__main__":
    main()
