Original source crops from DK3-Kong-all-frames.zip supplied for this project.
Contains M001–M076 body crops plus C001 for the original/game comparison.
manifest.json is the unmodified source catalogue; references to additional
composite images and earlier Atari comparisons describe the original archive.
Those extra images are not needed to rebuild DKFAST.

Original decoded pixel hashes are verified by tests/arcade_source.py.
Atari transcription: tools/arcade_redraw.py. No arcade ROM is bundled.
