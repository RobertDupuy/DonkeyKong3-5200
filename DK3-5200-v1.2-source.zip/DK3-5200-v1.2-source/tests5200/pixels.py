from check import *
import json,re
src=(ROOT/'tests/sprite_pixels.py').read_text();ref={};exec(src[:src.index("for tv in ['ntsc','pal']:")],ref)
compose=ref['compose'];backgrounds=(ROOT/'build/backgrounds.bin').read_bytes()
# Independent original art compositor, with immutable scenery from the 5200
# row dictionary reconstructed and flowers supplied from original patch art.
flowers=[]
for f in range(5):
 x=[24,42,60,78,96][f];phase=x%4;arr=bytearray(6144)
 vals=[]
 text=(ROOT/'src/flowers.inc').read_text().split('flower_pixels:')[1].split('flower_blank:')[0]
 vals=bytes(int(v) for line in text.splitlines() if '.byte' in line for v in line.split('.byte')[1].strip().split(','))
 for y in range(16):arr[(176+y)*32+x//4:(176+y)*32+x//4+3]=vals[(phase//2)*48+y*3:(phase//2)*48+y*3+3]
 flowers.append(arr)
def setv(e,**v):
 for k,x in v.items():
  for i,b in enumerate(x if isinstance(x,list) else [x]):e.poke(L[k]+i,b)
class Submitted:
 def __init__(self,data):self.d=data
 def mem(self,k,n=1):
  if k==0xa000:
   idx=self.val('bg_index');bg=bytearray(backgrounds[idx*6144:(idx+1)*6144])
   for i,x in enumerate([24,42,60,78,96]):
    phase=x%4;mask=[0,0,255] if phase==0 else [240,0,15]
    for y in range(16):
     for k in range(3):
      j=(176+y)*32+x//4+k
      v=flowers[i][j] if self.mem('flower',5)[i]==1 else 0
      bg[j]=(bg[j]&mask[k])|v
   return bg[:n]
  a=L.get(k,k);return self.d[a:a+n]
 def val(self,k):return self.mem(k)[0]
e=Emu();e.boot();e.step(30)
# PAUSE freezes gameplay; wait_ticks hides the notice while testing artwork.
setv(e,state=6,kong_floor=1,wait_ticks=240,ky=40,kong_dx=0,invuln=0,py=158,can_state=0,coconut_state=0,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2)
e.step(30);count=0
for pose in range(1,125):
 setv(e,kong_frame=pose);e.step(20)
 for sample in range(2):
  p=ROOT/'build/pixel-memory.bin';e.cmd(f'capture_memory {p} {L["pending"]} 1')
  for f in range(60):
   e.step()
   if e.cmd('capture_done')=='1':break
  else:raise AssertionError('no frame')
  s=Submitted(p.read_bytes());expected=compose(s);bank=s.val('back');actual=s.mem(0x1000+bank*6144,6144)
  diff=[(i%32,i//32,a,b) for i,(a,b) in enumerate(zip(actual,expected)) if a!=b]
  if diff:print('FAIL',pose,bank,len(diff),diff[:12]);e.shot('pixel-failure');raise SystemExit(1)
  count+=1
print('All pose bitmaps',count,'pass')
setv(e,state=6,kong_floor=1,wait_ticks=240,kong_frame=28,ky=40,kong_hit=0,kong_slip=0,kong_throw=0,coconut_clock=0,can_state=0,py=158,invuln=0,etype=[2,4,3,5,2,4,3,5,2,4],ehp=[2,1,1,1,1,1,1,1,2,1],emode=[2]*5+[0]*5,calive=[1]*4,cphase=[0,2,5,8],cstun=[0]*4,slife=[10,10],sage=[4,20],spower=[0,1],htype=[1,2]*4)
for phase in range(4):
 for y in [30,41,62,83]:
  setv(e,ex=[12+i*9+phase for i in range(10)],ey=[y+i*3 for i in range(10)],cx=[28+phase,48+phase,72+phase,92+phase],cy=[54,82,103,127],sx=[42+phase,62+phase],sy=[65,93],hx=[10+i*13+phase for i in range(8)],hy=[y+i*9 for i in range(8)])
  e.step(45)
  for sample in range(2):
   p=ROOT/'build/pixel-memory.bin';e.cmd(f'capture_memory {p} {L["pending"]} 1')
   for f in range(60):
    e.step()
    if e.cmd('capture_done')=='1':break
   s=Submitted(p.read_bytes());expected=compose(s);bank=s.val('back');actual=s.mem(0x1000+bank*6144,6144)
   diff=[(i%32,i//32,a,b) for i,(a,b) in enumerate(zip(actual,expected)) if a!=b]
   assert not diff,(phase,y,bank,len(diff),diff[:10])
   count+=1
print('All bitmap checks',count,'pass; ROM/PM deadline counts',e.cmd('port_stats'));e.close()
(ROOT/'build/pixel-results.json').write_text(json.dumps(dict(pose_frames=248,crowded_frames=32,all_passed=True)))
