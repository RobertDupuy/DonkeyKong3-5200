import sys,json,hashlib,gzip
from pathlib import Path
from check import Emu,L,ROOT
sys.path.append(str(ROOT/'tests'))
from tactical import control
class Snap:
 def __init__(self,e):self.data=e.mem(0x800,0x800)
 def mem(self,k,n=1):a=L[k]-0x800;return self.data[a:a+n]
 def val(self,k):return self.mem(k)[0]
 def word(self,k):return int.from_bytes(self.mem(k,2),'little')
for trial in range(8):
 e=Emu();e.step(250+trial*13);e.step(6,t=1);e.step(6);mem={};wins=[];prev=0;times=[];last=0;events=[];active=0;previous_front=e.val("front");flip_times=[];active_frames=0;active_flips=0
 for f in range(36000):
  s=Snap(e);state=s.val('state')
  if state==3 and prev!=3:wins.append({'round':s.val('level'),'reason':s.val('clear_reason'),'frame':f});print(trial,wins[-1],flush=True)
  if len(wins)==6 or state==5:break
  prev=state
  j,t=control(s,trial,mem,True)
  events.append([j,t]);e.step(1,j,t)
  front=e.val('front')
  if state==1 and e.val('state')==1:
   active_frames+=1
   if front!=previous_front:active_flips+=1
  previous_front=front
  count=e.word('render_count')
  if count!=last:
   if state==1 and active:times.append(f-active)
   last=count;active=f if state==1 else 0
  if f%2000==0:print('progress',trial,f,state,s.val('level'),s.val('lives'),flush=True)
 result=dict(trial=trial,wins=wins,frames=f,lives=e.val('lives'),complete=len(wins)==6,intervals=times,input_only=True,collect_super=True,boot_frames=250+trial*13,active_frames=active_frames,active_flips=active_flips,average_active_presentations_per_second=60*active_flips/active_frames,rom_pm_violations=e.cmd("port_stats"))
 e.shot('campaign-end');e.close()
 (ROOT/'build/5200-collected-campaign.json').write_text(json.dumps(result))
 with gzip.open(ROOT/f'build/5200-collected-campaign-{trial}.json.gz','wt') as f:json.dump(events,f)
 print({k:v for k,v in result.items() if k!='intervals'},flush=True)
 if result['complete']:break
