"""Replay the recorded six-round controller sequence without RAM fixtures."""
from check import *
import gzip,json
v=ROOT/'validation5200';meta=json.loads((v/'collected-campaign.json').read_text())
route=json.load(gzip.open(v/'collected-campaign-route.json.gz','rt'))
e=Emu();e.step(meta['boot_frames']);e.step(6,t=1);e.step(6);wins=[];prev=0
for f,(j,t) in enumerate(route):
 st=e.val('state')
 if st==3 and prev!=3:wins.append({'round':e.val('level'),'reason':e.val('clear_reason'),'frame':f})
 prev=st;e.step(1,j,t)
if e.val('state')==3 and prev!=3:wins.append({'round':e.val('level'),'reason':e.val('clear_reason'),'frame':len(route)})
assert wins==meta['wins'],(wins,meta['wins'])
assert e.val('lives')==meta['lives']
assert e.cmd('port_stats')=='0 0'
e.close();print('Exact input-only replay passes: six rounds, two lives remaining, no ROM writes or late PM writes.')
