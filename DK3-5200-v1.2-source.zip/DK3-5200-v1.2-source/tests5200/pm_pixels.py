from check import *
import json,struct
A=ROOT/'src/kong';cm=(A/'composite-map.bin').read_bytes();native=json.loads((A/'arcade-native.json').read_text())
def setv(e,**v):
 for k,x in v.items():
  for i,b in enumerate(x if isinstance(x,list) else [x]):e.poke(L[k]+i,b)
e=Emu();e.boot();setv(e,state=6,kong_floor=1,wait_ticks=240,ky=40,kong_dx=0,invuln=0,py=158,can_state=0,coconut_state=0,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2);e.step(30)
for pose in range(1,125):
 setv(e,kong_frame=pose);e.step(30)
 p=ROOT/'build/pm-commit.bin';e.cmd(f'capture_memory {p} {L["pending"]} 0')
 for _ in range(60):
  e.step()
  if e.cmd('capture_done')=='1':break
 data=p.read_bytes()
 sf=pose if pose<=122 else 5 if pose==123 else 2;body=cm[(sf-1)*8];pixels=[row[:] for row in native[body]['pixels']]
 hives=(A/'hive-art.bin').read_bytes();n=cm[(sf-1)*8+1]
 for j in range(n):
  tile,hx,hy=struct.unpack_from('<Bbb',cm,(sf-1)*8+2+j*3)
  for yy in range(16):
   for xx in range(8):
    v=(hives[tile*64+yy*4+xx//2]>>(4 if xx%2==0 else 0))&15
    if v and 0<=hx+xx<24:pixels[hy+yy][hx+xx]=0
 for plane in range(3):
  expected=bytes(sum(128>>b for b in range(8) if row[plane*8+b]==3) for row in pixels)
  actual=data[0x400+plane*256+80:0x400+plane*256+80+len(expected)]
  assert actual==expected,(pose,plane,[(i,a,b) for i,(a,b) in enumerate(zip(actual,expected)) if a!=b][:5])
print('372 PM plane checks pass;',e.cmd('port_stats'));e.log.seek(0);print(e.log.read());e.close()

(ROOT/'build/pm-pixel-results.json').write_text(json.dumps(dict(poses=124,plane_checks=372,all_passed=True)))
