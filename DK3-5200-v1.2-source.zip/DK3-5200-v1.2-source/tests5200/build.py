from pathlib import Path
import subprocess,os
R=Path(__file__).resolve().parents[1];A=Path(os.environ.get('ATARI800_SOURCE',str(R.parent/'research/atari800/src')))
s=(R/'tests/emulator.c').read_text()
a=s.index(' char *osrom=');b=s.index(' puts("READY")',a)
s=s[:a]+''' char*args[]={"atari800","-5200","-5200-rev","altirra",argv[1],"-sound","-audio16","-cart",argv[2],"-config","/tmp/dk5200-test.cfg"};
 if(!libatari800_init(11,args))return 3;
'''+s[b:]
s=s.replace('#include "monitor.h"','#include "monitor.h"\n#include "akey.h"\n#include "cartridge.h"')
s=s.replace('in.start=st;in.select=se;','in.keycode=st==2?AKEY_5200_RESET:st==3?AKEY_5200_START:st?AKEY_5200_PAUSE:se?AKEY_5200_1:0;')
s=s.replace('int trace=0;', 'int trace=0; unsigned bad_writes=0,pm_late=0;')
s=s.replace('void hg_monitor_write(unsigned short a,unsigned char b){', 'void hg_monitor_write(unsigned short a,unsigned char b){\n if(a>=0x4000 && a<0xbfc0) {bad_writes++;fprintf(stderr,"ROM WRITE %04x PC %04x\\n",a,CPU_regPC);exit(30);}\n if(a>=0x400 && a<0x800 && ANTIC_DMACTL && ANTIC_ypos>=32 && ANTIC_ypos<240 && (a&255)<=ANTIC_ypos) { if(pm_late<12)fprintf(stderr,"LATE %04x y%d x%d PC%04x\\n",a,ANTIC_ypos,ANTIC_XPOS,CPU_regPC);pm_late++; }\n')
s=s.replace('}else if(!strcmp(cmd,"profile_start")){','}else if(!strcmp(cmd,"port_stats")){printf("%u %u\\n",bad_writes,pm_late);fflush(stdout);'+
 ' }else if(!strcmp(cmd,"profile_start")){')
s=s.replace('}else if(!strcmp(cmd,"profile_start")){','}else if(!strcmp(cmd,"ramfill")){unsigned seed;scanf("%u",&seed);unsigned char*m=libatari800_get_main_memory_ptr();for(int i=0;i<0x4000;i++){seed=seed*1664525u+1013904223u;m[i]=seed>>24;}puts("OK");fflush(stdout);'+
 ' }else if(!strcmp(cmd,"profile_start")){')
# Original write observer for tick-synchronous fixtures remains in the harness.
s=s.replace('m[0x22f]', 'm[0x22f]')
(R/'build/emulator5200.c').write_text(s)
subprocess.run(['cc','-O2','-I'+str(A),str(R/'build/emulator5200.c'),str(R/'tests/profile_stubs.c'),str(A/'libatari800.a'),'-lm','-lz','-o',str(R/'build/emulator')],check=True)
