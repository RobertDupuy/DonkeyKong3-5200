from pathlib import Path
import subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
L={}
for line in (ROOT/'build/game.lbl').read_text().splitlines():
 parts=line.split()
 if len(parts)==3:
  name=parts[2].lstrip('.')
  if name.startswith('_'):L[name[1:]]=int(parts[1],16)
  elif name not in L:L[name]=int(parts[1],16)

class Emu:
 def __init__(self,car=None):
  self.log=tempfile.TemporaryFile(mode='w+t');self.pokes=[]
  self.p=subprocess.Popen([str(ROOT/'build/emulator'),'-ntsc',str(car or ROOT/'build/DK3-5200-v0.2.car')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True)
  while self.p.stdout.readline().strip()!='READY':
   if self.p.poll() is not None:self.log.seek(0);raise RuntimeError(self.log.read())
 def cmd(self,c):
  self.p.stdin.write(c+'\n');self.p.stdin.flush();a=self.p.stdout.readline().strip()
  if not a:self.log.seek(0);raise RuntimeError(c+'\n'+self.log.read())
  return a
 def step(self,n=1,j=0,t=0,start=0,sel=0):
  if self.pokes:
   for a,v in self.pokes:self.cmd(f'queue {a} {v}')
   self.cmd(f'apply {L["logic_ticks"]}');self.pokes=[]
  return self.cmd(f'step {n} {j} {t} {start} {sel}')
 def mem(self,a,n=1):return bytes.fromhex(self.cmd(f'mem {L.get(a,a)} {n}'))
 def val(self,a):return self.mem(a)[0]
 def word(self,a):return int.from_bytes(self.mem(a,2),'little')
 def poke(self,a,v):
  addr=L.get(a,a);self.pokes.append((addr,v&255))
  if a in ['fall_clock','bonus_tick','fall_period','bonus_period','coconut_wait','coconut_period']:self.pokes.append((addr+1,v>>8))
 def shot(self,name):return self.cmd(f'shot {ROOT}/build/{name}.ppm')
 def boot(self):
  self.step(250);self.step(5,t=1);self.step(3)
  for _ in range(400):
   if self.val('state')==1:return
   self.step(3)
  raise RuntimeError('Boot failed')
 def close(self):self.cmd('quit') if False else None;self.p.stdin.write('quit\n');self.p.stdin.flush();self.p.wait();self.log.close()
