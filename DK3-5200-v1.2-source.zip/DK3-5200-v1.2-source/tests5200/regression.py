from check import *
import json,csv
checks=[]
def check(name,ok,detail=None):
 checks.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**v):
 for k,x in v.items():
  for i,b in enumerate(x if isinstance(x,list) else [x]):e.poke(L[k]+i,b)
def quiet(e):setv(e,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,spawn_clock=250,swarm_left=100,invuln=250,can_state=0,coconut_state=0)
def stage(e,level):
 if level==1:return
 setv(e,level=level-1,state=3,wait_ticks=0)
 for _ in range(600):
  e.step()
  if e.val('level')==level and e.val('state')==1:return
 raise AssertionError(('stage',level))
for bank in range(4):
 for seed in [0,1,42,255,5200,65535,0xdeadbeef,0xffffffff]:
  e=Emu();e.cmd(f'ramfill {seed}');e.cmd(f'io {0xbfd0+bank*4} 0');e.step(300)
  check(f'cold start bank {bank} seed {seed}',e.val('state')==0 and e.val('fps')==60)
  e.step(6,start=3)
  for _ in range(400):
   e.step()
   if e.val('state')==1:break
  check(f'START enters play bank {bank} seed {seed}',e.val('state')==1)
  e.close()
print('32 cold starts and START checks pass',flush=True)
e=Emu();e.boot();quiet(e);e.step(20)
for key in [1,1]:e.step(6,start=key);e.step(6)
check('pause and resume',e.val('state')==1)
e.step(6,sel=1);e.step(6);check('keypad 1 mutes music',e.val('music_enabled')==0)
for j,axis,sign in [(8,'px',1),(4,'px',-1),(1,'py',-1)]:
 before=e.val(axis);e.step(20,j=j);after=e.val(axis);check(f'analog direction {j}',(after-before)*sign>0,(before,after))
for n in range(20):
 e.step(6,start=2,t=n%2);e.step(30);check(f'controller RESET {n} reaches title',e.val('state')==0)
 e.step(6,start=3)
 for _ in range(400):
  e.step()
  if e.val('state')==1:break
 check(f'restart {n}',e.val('state')==1)
e.close();print('Controls and repeated RESET pass',flush=True)
for level in [1,2,4]:
 for trigger in ['descent','vines']:
  for px in [8,60,112]:
   e=Emu();e.boot();stage(e,level);quiet(e)
   ky=79 if trigger=='descent' else 24
   setv(e,px=px,py=70 if px==60 else 158,jump_phase=0,invuln=0,lives=2,ky=ky,kong_hit=0,kong_recover=0,kong_pending=0,kong_floor=0,kong_dx=0,bonus_hundreds=80 if trigger=='descent' else 0,vine_y=ky+26,vine_tick=3)
   e.poke('fall_clock',e.word('fall_period')-80 if trigger=='descent' else 0)
   poses=set();entered=False
   for _ in range(420):
    e.step();st=e.val('state');entered|=st==4
    if st==4:poses.add(e.val('kong_frame'))
    if entered and st==2:break
   check(f'defeat {level}/{trigger}/{px} one life',entered and e.val('lives')==1 and e.val('state')==2)
   check(f'defeat {level}/{trigger}/{px} animation',{107,108,109,110,111}<=poses,sorted(poses))
   check(f'defeat {level}/{trigger}/{px} ROM and PM deadlines',e.cmd('port_stats')=='0 0')
   e.close()
print('18 defeat fixtures pass',flush=True)
for music in [0,1]:
 e=Emu();e.boot();quiet(e);setv(e,music_enabled=music);e.step(12);setv(e,state=1,px=76,py=118,floor_id=2,ky=24,can_state=2,can_y=116,can_used=0,super_seconds=0,super_tick=0,sfx=0,sfx_ticks=0,music_enabled=music)
 p=ROOT/f'build/5200-super-{music}.csv';e.cmd(f'soundwatch {p} {L["logic_ticks"]}')
 for f in range(120):e.step(1,t=int(f%12==0))
 e.cmd('soundstop');rows=list(csv.DictReader(p.open()));notes=[int(r['f1']) for r in rows if int(r['c1'])==0xa5]
 check(f'protected four-note cue music={music}',notes==[n for n in [60,47,40,30] for _ in range(6)],notes)
 check(f'Super Spray duration music={music}',e.val('super_seconds') in [13,14] and e.val('can_used')==1)
 if not music:check('music muted, effects retained',all(not int(r['c'+str(ch)])&15 for r in rows for ch in [2,3,4]))
 e.close()
print('Super Spray audio passes',flush=True)
# Start every supported round; scene selection and cap values remain inherited.
e=Emu();e.boot()
for level in range(1,100):
 if level>1:stage(e,level)
 check(f'round {level} starts',e.val('state')==1 and e.val('level')==level)
 quiet(e);e.step(12)
check('all-round ROM/deadline checks',e.cmd('port_stats')=='0 0');e.close()
print('All 99 round starts pass',flush=True)
(ROOT/'build/5200-regression.json').write_text(json.dumps(dict(checks=checks,all_passed=True),indent=2))
print('Passed',len(checks),'checks')
