"""Compare v0.1/v0.2 raster output at the top trestle in both buffers."""
from check import *
import json
from PIL import Image

def setv(e,**values):
 for k,v in values.items():
  for i,b in enumerate(v if isinstance(v,list) else [v]):e.poke(L[k]+i,b)

def fixture(car,level):
 e=Emu(car);e.boot()
 if level!=1:
  setv(e,level=level-1,state=3,wait_ticks=0)
  for _ in range(600):
   e.step()
   if e.val('level')==level and e.val('state')==1:break
  else:raise AssertionError('stage startup')
 setv(e,state=6,wait_ticks=240,ky=24,kong_frame=1,kong_hit=0,kong_floor=0,kong_dx=0,
      px=60,py=118,invuln=0,can_state=0,coconut_state=0,
      etype=[0]*10,htype=[0]*8,slife=[0]*2,
      calive=[1,1,0,0],cx=[80,32,0,0],cy=[127,123,0,0],cphase=[0]*4,cstun=[0]*4,cdir=[1]*4)
 e.step(45)
 return e

results=[]
for level in [1,2,4]:
 captures=[]
 for build,car in [('before',ROOT/'tests5200/data/DK3-5200-v0.1.car'),('after',ROOT/'build/DK3-5200-v0.2.car')]:
  e=fixture(car,level);buffers={}
  for _ in range(30):
   e.step()
   front=e.val('front');path=ROOT/f'build/palette-{level}-{build}-{front}.raw'
   e.cmd(f'screen {path}');buffers[front]=path.read_bytes()
   if len(buffers)==2:break
  assert len(buffers)==2
  e.shot(f'palette-{level}-{build}')
  assert e.cmd('port_stats')=='0 0'
  e.close();captures.append(buffers)
 before,after=captures
 for front in [0,1]:
  changed=[(i%384,i//384,a,b) for i,(a,b) in enumerate(zip(before[front],after[front])) if a!=b]
  assert changed,('no correction',level,front)
  rows=sorted(set(p[1] for p in changed))
  print(level,front,'changed rows',rows,'colors',sorted(set((p[2],p[3]) for p in changed)))
  # The bitmap starts at framebuffer row 32; the old palette write was late by one row.
  assert all(161<=y<=165 for _,y,_,_ in changed),(level,front,rows)
  # Top trestle starts at framebuffer row 166 and must remain unchanged.
  assert before[front][166*384:176*384]==after[front][166*384:176*384]
  assert any(a in [0x88,0x08,0x1a] and b==0xc6 for _,_,a,b in changed)
  results.append(dict(level=level,buffer=front,changed_pixels=len(changed),changed_framebuffer_rows=rows))
 im=Image.open(ROOT/f'build/palette-{level}-after.ppm')
 im.resize((1536,960),Image.Resampling.NEAREST).save(ROOT/f'build/palette-{level}-after.png')
(ROOT/'build/palette-boundary.json').write_text(json.dumps(dict(all_passed=True,cases=results),indent=2))
