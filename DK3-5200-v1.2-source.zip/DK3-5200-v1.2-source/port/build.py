from pathlib import Path
import subprocess,os,sys,shutil,struct,json,re
R=Path(__file__).resolve().parents[1];B=R/'build';P=B/'port';P.mkdir(exist_ok=True,parents=True)
if os.environ.get('CC65_HOME'):
 T=Path(os.environ['CC65_HOME'])
else:
 ca=shutil.which('ca65')
 if not ca:raise SystemExit('Install cc65 or set CC65_HOME to its data directory (include/, asminc/, lib/).')
 prefix=Path(ca).resolve().parents[1]
 T=next((p for p in [prefix/'share/cc65',prefix,Path('/usr/share/cc65')] if (p/'lib/none.lib').exists()),None)
 if T is None:raise SystemExit('Set CC65_HOME to the directory containing include/ and lib/none.lib.')
def tool(n):
 candidates=[shutil.which(n),str(T/'bin'/n),str(T.parent.parent/'bin'/n)]
 found=next((p for p in candidates if p and Path(p).is_file()),None)
 if not found:raise SystemExit('Cannot find '+n+'; add cc65 executables to PATH.')
 return found
def run(*args):subprocess.run([str(x) for x in args],check=True,cwd=R)
run(sys.executable,R/'port/prepare.py');run(sys.executable,R/'port/assets.py')
run(tool('cc65'),'-t','none','-Oirs','--static-locals','--cpu','6502','-I',T/'include','-I',R/'src','-o',P/'game.s',P/'game.c')
for n in ['game','logic','music','messages']:
 run(tool('ca65'),'--bin-include-dir',R/'src','-g','-l',B/(n+'.lst'),'-I',P,'-I',R/'src','-I',T/'asminc','-o',B/(n+'.o'),P/(n+'.s'))
run(tool('ld65'),'-C',R/'port/linker.cfg','-m',B/'game.map','-Ln',B/'game.lbl','-o',B/'code.bin',*[B/(n+'.o') for n in ['logic','game','music','messages']],T/'lib/none.lib')
rom=bytearray((B/'cart-assets.bin').read_bytes());code=(B/'code.bin').read_bytes();common=(B/'code.bin.common').read_bytes()
assert len(code)<=0x7800 and len(common)<=0x7c0
rom[:len(code)]=code
for bank in range(4):rom[bank*32768+0x7800:bank*32768+0x7800+len(common)]=common
# Diagnostic cartridge: own startup initializes all hardware and vectors.
labs={s[2].lstrip('.'):int(s[1],16) for l in (B/'game.lbl').read_text().splitlines() if len(s:=l.split())==3}
for bank in range(4):
 rom[bank*32768+0x7ffd]=255
 rom[bank*32768+0x7ffe:bank*32768+0x8000]=struct.pack('<H',labs['boot'])
(B/'DK3-5200-v0.2.rom').write_bytes(rom)
(B/'DK3-5200-v0.2.car').write_bytes(b'CART'+struct.pack('>III',72,sum(rom)&0xffffffff,0)+rom)
print('Code',len(code),'common',len(common),'BSS',labs.get('__BSS_SIZE__'),'ROM',len(rom))
