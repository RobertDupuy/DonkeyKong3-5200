"""Generate the console build from the preserved DKFAST v0.3 gameplay source."""
from pathlib import Path
import re
R=Path(__file__).resolve().parents[1];S=R/'src';P=R/'build/port';P.mkdir(parents=True,exist_ok=True)
def flat(s):
 s=re.sub(r'\.segment "(?!ZEROPAGE|BSS|KVAR)[^"]+"','.segment "CODE"',s)
 s=s.replace('.segment "KVAR"','.segment "BSS"')
 return re.sub(r'\$d0([0-9a-fA-F]{2})',r'$c0\1',re.sub(r'\$d2([0-9a-fA-F]{2})',r'$e8\1',s))
for f in S.glob('*.inc'):(P/f.name).write_text(flat(f.read_text()))
g=(S/'game.c').read_text()
# Static scenery becomes immutable row dictionaries in cartridge ROM.
a=g.index('static void pixel(');b=g.index('void add_points',a);g=g[:a]+g[b:]
a=g.index('/* Framed arcade trestles.');b=g.index('static u8 floor_y',a)
g=g[:a]+'''static void scenery(void){
 palette();copy_background();screen_on();scene_built=1;
}
'''+g[b:]
g=g.replace('  box(56,0,16,16,0);box(56,4,16,1,1);box(56,4,1,10,1);','')
g=g.replace('if(layout!=2){hive(24,6);hive(92,6);copy_background();scene_built=1;}','')
g=g.replace('   for(a=0;a<23;++a){pixel(30+a,(22-a)/4,1);pixel(97-a,(22-a)/4,1);}','')
g=g.replace('joy=PEEK(0xd300)&15;console=PEEK(0xd01f);fire=0;', 'joy=keyjoy;console=7;fire=0;')
g=g.replace('extern volatile u8 keyfire,keyconsole,keyselect;','extern volatile u8 keyfire,keyconsole,keyselect,keyjoy,keyreset;\nu8 reset_seen;')
g=g.replace(' ++logic_ticks;',' if(keyreset!=reset_seen){reset_seen=keyreset;fire_seen=keyfire;start_seen=keyconsole;select_seen=keyselect;title_screen();return;}\n ++logic_ticks;')
g=re.sub(r'#pragma (?:bss|rodata|code)-name\([^\n]+\n','',g)
(P/'game.c').write_text(g)
# Pull in unchanged assembly gameplay and collision functions.
e=(S/'engine.s').read_text()
head=e[:e.index('.segment "BSS"')]
head=head.replace('.import __HIVECODE_LOAD__,__KLOOKUP_LOAD__','').replace('.import __LOWCODE_LOAD__,__LOWCODE_RUN__,__LOWCODE_SIZE__','').replace('.import __KVAR_RUN__,__KVAR_SIZE__','')
head=head.replace('.import _notice_restore,_notice_draw,notice_old','.import _notice_draw,notice_old')
head=head.replace('.export _pm_art','.export _pm_art')
logic=e[e.index('.import _hx,_hy'):e.index('.segment "ART"\nbitmask')]
creeps=e[e.index('_draw_creeps:'):e.index('.segment "ART"\n_pm_art')]
(P/'logic.s').write_text(flat(head)+ '\n'+(R/'port/engine.s').read_text()+'\n'+flat(logic)+flat(creeps)+'''
.segment "CODE"
creep_pose: .byte 0,0,1,1,1,2,2,1,1,1
.segment "COMMON"
_pm_art: .incbin "pm_art.bin",0,256
.segment "CODE"
.include "render_scene.inc"
.include "defeat.inc"
.include "kong_timeline.inc"
.include "sound.inc"
.include "coconut.inc"
.include "spray_fast.inc"
.include "contact_masks.inc"
.include "enemy_fast.inc"
.include "ntsc_timing.inc"
.include "interpolation.inc"
.include "hud_fast.inc"
.include "tables.inc"
''')
# Interpolation state must live in RAM; generated execution remains ROM.
s=(P/'interpolation.inc').read_text();s=s.replace('.segment "CODE"\n_render_phase:', '.segment "BSS"\n_render_phase:');s=s.replace('_snapshot_motion:', '.segment "CODE"\n_snapshot_motion:');s=re.sub(r'\.byte 0', '.res 1',s,count=3);s=s.replace('.res 54,0','.res 54');(P/'interpolation.inc').write_text(s)
# HUDs have separate pending/front buffers and a canonical work copy.
s=(P/'hud_fast.inc').read_text();s=re.sub(r'\$5e([89ab][0-9a-f])',lambda m:'hudwork+'+str(int(m[1],16)-128),s)
s=s.replace('sta _hud_dirty','sta _hud_dirty')
s=s.replace(' .byte 0,36,43,38,33,51,52,0,54,16,14,19,0,13,0,33,52,33,50,41,0,24,16,16,56,44,0',' .byte 0,36,43,19,0,21,18,16,16,0,54,16,14,18,0,0,0,0,0,0,0,0,0,0,0,0,0')
(P/'hud_fast.inc').write_text(s)
(P/'music.s').write_text(flat((S/'music.s').read_text()))
# Notices render into the hidden bitmap. The background restore is done by
# the console renderer, and PM occlusion is applied in VBI at commit.
s=flat((S/'messages.s').read_text()).replace('START TO CONTINUE','PAUSE TO RESUME').replace('.export _bonus_message','.export draw_bonus')
s=s.replace('_bonus_message:', 'draw_bonus:').replace(' lda #$a0\n sta message_page',' jsr back_page',1).replace(' jmp _copy_background',' rts',1)
a=s.index('@restore_row:');b=s.index('message_advance:',a);s=s[:a]+'@restore_row:\n rts\n'+s[b:]
a=s.index(' sec\n sbc message_page',s.index('message_advance:'));b=s.index(' rts',a);s=s[:a]+s[b:]
s=s.replace(' lda #$80\n bne @set\n:lda #$60',' lda #$28\n bne @set\n:lda #$10')
a=s.index(' txa\n asl\n asl\n asl',s.index('_notice_draw:'));b=s.index('\n.segment "CODE"',a);s=s[:a]+' rts\n'+s[b:]
(P/'messages.s').write_text(s)
