.segment "CODE"
; Native 16 KB 5200 engine. All executable code remains in cartridge ROM.
; $1000-$27ff and $2800-$3fff are double buffered 128x192 playfields.
; $0300-$07ff is one PM bank, updated atomically by VBI from frame descriptors.
.import __DATA_LOAD__,__DATA_RUN__,__DATA_SIZE__
.import _level,_flower,_flower_x,_music_enabled,_random_seed
.import draw_bonus
.export _keyreset,boot
.segment "ZEROPAGE"
rectptr: .res 2
bgtab: .res 2
bgtabhi: .res 2
nptr: .res 2
nptr1: .res 2
nptr2: .res 2
.segment "BSS"
_plotx:.res 1
_ploty:.res 1
_plotc:.res 1
_logic_ticks:.res 2
_late_frames:.res 1
_keyjoy:.res 1
_keyfire:.res 1
_keyconsole:.res 1
_keyselect:.res 1
_keyreset:.res 1
input_fire_prev:.res 1
key_prev:.res 1
active_bank:.res 1
nmi_bank:.res 1
raster:.res 1
music_phase:.res 1
dma_shadow:.res 1
bg_dirty:.res 2
old_count:.res 2
old_x:.res 80
old_y:.res 80
old_w:.res 80
old_h:.res 80
old_kx:.res 2
old_ky:.res 2
old_kw:.res 2
old_kh:.res 2
old_pose:.res 2
old_dx:.res 2
kong_redraw:.res 1
oldnotice:.res 2
oldoff_bank:.res 1
rectx:.res 1
recty:.res 1
rectw:.res 1
recth:.res 1
bg_index:.res 1
bg_oldindex:.res 2
bg_bank:.res 1
asset_width:.res 1
asset_height:.res 1
actor_index:.res 1
kong_x:.res 1
kong_dx_screen:.res 1
pm_pose:.res 2
pm_y:.res 2
pm_x:.res 2
pm_manx:.res 2
pm_many:.res 2
pm_manpose:.res 2
pm_hx0:.res 2
pm_hx1:.res 2
pm_hy0:.res 2
pm_hy1:.res 2
pm_cutscene:.res 2
pm_hide:.res 2
pm_notice:.res 2
pm_height:.res 1
pm_prev_y:.res 1
pm_prev_h:.res 1
pm_prev_man:.res 1
pm_prev_h0:.res 1
pm_prev_h1:.res 1
nmi_count:.res 1
nmi_index:.res 1
skin_color:.res 1
fur_color:.res 1
hive_color:.res 1
paloff:.res 1
display_pal0:.res 54
display_pal1:.res 54
display_pal2:.res 54
hud0:.res 64
hud1:.res 64
hudwork:.res 64
.export _hud_dirty
_hud_dirty:.res 2
bonus_flag:.res 1
flower_dirty:.res 2
; BIOS dispatches NMI through $0202/$0206. These do not save registers.
.segment "COMMON"
boot:
 sei
 cld
 lda #0
 sta $d40e
 sta $d400
 sta $e80e
 bit $bfd0
 jmp start5200
vbi_entry:
 pha
 txa
 pha
 tya
 pha
 lda active_bank
 sta nmi_bank
 bit $bfd0
 jmp vbi5200
vbi_exit:
 lda nmi_bank
 asl
 asl
 tax
 lda $bfd0,x
 pla
 tay
 pla
 tax
 pla
 rti
; These routines are identical in every cartridge bank. NMI temporarily
; selects the code bank and restores whichever asset bank was interrupted.
asset_call:
 sta active_bank
 asl
 asl
 tax
 lda $bfd0,x
 jsr dispatch
 lda #0
 sta active_bank
 bit $bfd0
 rts
dispatch: jmp (src)
asset_compiled:
 sta active_bank
 asl
 asl
 tax
 lda $bfd0,x
 ldy #0
 lda (src),y
 pha
 ldy rows
 lda (src),y
 sta src+1
 pla
 sta src
 ldx rows
 jsr dispatch
 lda #0
 sta active_bank
 bit $bfd0
 rts
asset_kong:
 sta active_bank
 asl
 asl
 tax
 lda $bfd0,x
@row:
 ldy asset_width
 dey
@col:
 lda (src),y
 tax
 lda inverse_pf,x
 and (dst),y
 sta tmp
 txa
 ora tmp
 sta (dst),y
 dey
 bpl @col
 clc
 lda src
 adc asset_width
 sta src
 bcc :+
 inc src+1
:clc
 lda dst
 adc #32
 sta dst
 bcc :+
 inc dst+1
:dec rows
 bne @row
 lda #0
 sta active_bank
 bit $bfd0
 rts
background_rect:
 lda #3
 sta active_bank
 bit $bfdc
@row:
 ldy recty
 lda (bgtab),y
 sta src
 lda (bgtabhi),y
 sta src+1
 clc
 lda src
 adc rectx
 sta src
 bcc :+
 inc src+1
:ldy rectw
 dey
@byte:
 lda (src),y
 sta (dst),y
 dey
 bpl @byte
 clc
 lda dst
 adc #32
 sta dst
 bcc :+
 inc dst+1
:inc recty
 dec recth
 bne @row
 lda #0
 sta active_bank
 bit $bfd0
 rts
pm_copy_asset:
 ; VBI-private pointers: do not corrupt an interrupted foreground blit.
 asl
 asl
 tax
 lda $bfd0,x
 ldy #0
 ldx nmi_index
@row:
 lda (nptr),y
 sta $0400,x
 lda (nptr1),y
 sta $0500,x
 lda (nptr2),y
 sta $0600,x
 inx
 iny
 cpy pm_height
 bne @row
 bit $bfd0
 rts
; 27 short vertical palette events; no horizontal color kernel.
dli:
 pha
 txa
 pha
 tya
 pha
 lda _front
 beq :+
 lda #27
:clc
 adc raster
 tax
 lda display_pal0,x
 sta $d40a
 sta $c016
 lda display_pal1,x
 sta $c017
 lda display_pal2,x
 sta $c018
 ldy _front
 lda raster
 cmp #2
 bne @man
 lda pm_x,y
 sta $c000
 clc
 adc #8
 sta $c001
 adc #8
 sta $c002
 lda pm_hx0,y
 sta $c003
 lda skin_color
 sta $c012
 sta $c013
 sta $c014
 lda #$1c
 sta $c015
 jmp @out
@man:
 cmp #16
 bne @out
 lda pm_cutscene,y
 bne @out
 lda pm_manx,y
 sta $c000
 sta $c001
 sta $c002
 sta $c003
 lda #$46
 sta $c012
 lda #$2c
 sta $c013
 lda #$86
 sta $c014
 lda #$0e
 sta $c015
@out:
 inc raster
 pla
 tay
 pla
 tax
 pla
 rti
inverse_pf:
.repeat 256,I
 .byte ((I&$c0=0)*$c0)+((I&$30=0)*$30)+((I&$0c=0)*$0c)+((I&$03=0)*$03)
.endrepeat
; ANTIC must see identical display lists in every bank, including asset reads.
.macro DISPLAY name,addr,hud
name:
 .byte $70,$f0,$c2
 .word hud
 .byte $82
 .repeat 192,I
  .if I=0 .or ((addr+I*32)&$fff)=0
   .byte $4e
   .word addr+I*32
  ; Align the palette write with the first trestle row (134). This handler's
  ; entry/WSYNC latency needs the DLI at 132. Retain the next DLI at row 135.
  ; Caterpillars and vines above the trestle therefore keep their green.
  .elseif (I .mod 8=7 .and I<>127) .or I=132
   .byte $8e
  .else
   .byte $0e
  .endif
 .endrepeat
 .byte $41
 .word name
.endmacro
 .align 256
DISPLAY dl0,$1000,hud0
 .align 256
DISPLAY dl1,$2800,hud1
.segment "CODE"
start5200:
 ldx #$ff
 txs
 ; Initialize the whole 16 KB without relying on the console BIOS or loader.
 lda #0
 sta dst
 sta dst+1
 tay
 ldx #64
@clear:
 sta (dst),y
 iny
 bne @clear
 inc dst+1
 dex
 bne @clear
 lda #<$02ff
 sta sp
 lda #>$02ff
 sta sp+1
 ldx #0
@data:
 lda __DATA_LOAD__,x
 sta __DATA_RUN__,x
 inx
 cpx #<__DATA_SIZE__
 bne @data
 lda #<vbi_entry
 sta $0202
 lda #>vbi_entry
 sta $0203
 lda #<dli
 sta $0206
 lda #>dli
 sta $0207
 lda #<irq
 sta $0200
 lda #>irq
 sta $0201
 lda #1
 sta _back
 sta input_fire_prev
 lda #255
 sta key_prev
 lda #60
 sta _fps
 lda #$34
 sta fur_color
 lda #$3c
 sta skin_color
 lda #$2c
 sta hive_color
 lda #0
 sta _front
 jsr _hw_init
 jsr _main
 jmp boot
irq:rti
_hw_init:
 lda #4
 sta $c01f                 ; enable pots, select controller port 1
 lda #2
 sta $e80f                 ; scan enabled, debounce OFF for 5200 matrix
 lda #3
 sta $c01d                 ; PM DMA enabled
 lda #0
 sta $e808
 sta $e801
 sta $e803
 sta $e805
 sta $e807
 sta $d407                 ; PMBASE=$0000
 sta $c008
 sta $c009
 sta $c00a
 sta $c00b
 sta $c00c
 sta $c01a
 sta $c01e
 sta $e80b                 ; start first pot scan
 lda #$11
 sta $c01b
 lda #$f8
 sta $d409                 ; console BIOS font; no XL OS dependency
 lda #<dl0
 sta $d402
 lda #>dl0
 sta $d403
 lda #$c0
 sta $d40e
 rts
_screen_on:
 lda #$3d
 sta dma_shadow
 rts
_screen_off:
 lda #0
 sta dma_shadow
 sta $d400
 rts
_wait_frame:
 lda _frames
@wait:cmp _frames
 beq @wait
 rts
vbi5200:
 jsr sample_controls
 lda dma_shadow
 sta $d400
 lda #$f8
 sta $d409
 lda #2
 sta $d401
 lda #$11
 sta $c01b
 lda #0
 sta $c01a
 sta $d40f
 sta raster
 lda _pending
 beq @noflip
 lda _back
 sta _front
 eor #1
 sta _back
 ldx _front
 lda dllow,x
 sta $d402
 lda dlhigh,x
 sta $d403
 jsr update_pm
 lda #0
 sta _pending
@noflip:
 clc
 lda music_phase
 adc #25
 cmp _fps
 bcc @music_wait
 sbc _fps
 sta music_phase
 jsr _music_update
 jmp @done
@music_wait:sta music_phase
@done:
 inc _frames
 jmp vbi_exit
dllow:.byte <dl0,<dl1
dlhigh:.byte >dl0,>dl1
sample_controls:
 lda #15
 ldx $e800
 cpx #80
 bcs :+
 and #11
:cpx #150
 bcc :+
 and #7
:ldx $e801
 cpx #80
 bcs :+
 and #14
:cpx #150
 bcc :+
 and #13
:sta _keyjoy
 lda #0
 sta $e80b
 lda $c010
 cmp input_fire_prev
 beq @key
 sta input_fire_prev
 cmp #0
 bne @key
 inc _keyfire
@key:
 lda $e80f
 and #4
 beq @pressed
 lda #255
 sta key_prev
 rts
@pressed:
 lda $e809
 and #$1e
 cmp key_prev
 beq @done
 sta key_prev
 cmp #$18                  ; START
 bne :+
 inc _keyfire
 rts
:cmp #$10                  ; PAUSE
 bne :+
 inc _keyconsole
 rts
:cmp #$08                  ; RESET
 bne :+
 inc _keyreset
 rts
:cmp #$1e                  ; keypad 1: music on/off
 bne @done
 inc _keyselect
@done:rts
_clear_background:
_put_pixel:
_game_art:rts
_title_art:
 lda #0
 sta bonus_flag
 rts
_copy_background:
 lda #1
 sta bg_dirty
 sta bg_dirty+1
 rts
.export _plant,_bonus_message
_plant:
 lda #1
 sta flower_dirty
 sta flower_dirty+1
 rts                         ; flower state is composited into each hidden picture
_bonus_message:
 lda #1
 sta bonus_flag
 jmp _copy_background
; Renderer helpers use page=$10 or $28 and rowlo/rowhi for all addresses.
rect_address:
 ldx recty
 lda rowlo,x
 clc
 adc rectx
 sta dst
 lda rowhi,x
 adc page
 sta dst+1
 rts
restore_rect:
 lda recty
 clc
 adc recth
 cmp #176
 bcc :+
 ldx _back
 lda #1
 sta flower_dirty,x
:lda rectw
 beq @done
 lda recth
 beq @done
 jsr rect_address
 jsr background_rect
@done:rts
choose_background:
 lda _layout
 asl
 asl
 sta bg_index
 lda _state
 cmp #2
 bne :+
 lda bg_index
 clc
 adc #2
 sta bg_index
:lda _level
 cmp #15
 bcc :+
 inc bg_index
:lda _state
 cmp #3
 bne :+
 lda _layout
 cmp #2
 bne :+
 lda #12
 sta bg_index
:ldx _back
 lda bg_index
 cmp bg_oldindex,x
 beq :+
 sta bg_oldindex,x
 lda #1
 sta bg_dirty,x
:ldx bg_index
 lda bg_lo,x
 sta bgtab
 sta bgtabhi
 lda bg_hi,x
 sta bgtab+1
 sta bgtabhi+1
 clc
 lda bgtabhi
 adc #192
 sta bgtabhi
 bcc :+
 inc bgtabhi+1
:rts
_render:
 lda _pending
 bne _render
 lda _back
 beq :+
 lda #$18
:clc
 adc #$10
 sta page
 lda _back
 beq :+
 lda #40
:sta oldoff_bank
 jsr choose_background
 lda _state
 jne @game
 jsr draw_title
 jmp @submit
@game:
 lda #1
 sta kong_redraw
 ldx _back
 lda bg_dirty,x
 beq @restore
 lda #0
 sta old_count,x
 sta old_kw,x
 sta oldnotice,x
 sta bonus_flag
 lda #0
 sta rectx
 sta recty
 lda #32
 sta rectw
 lda #192
 sta recth
 jsr restore_rect
 jmp @restored
@restore:
 lda old_pose,x
 cmp _kong_frame
 bne @restorekong
 lda old_ky,x
 cmp _ky
 bne @restorekong
 lda old_dx,x
 cmp _kong_dx
 bne @restorekong
 lda #0
 sta kong_redraw
 jmp @restorenotice
@restorekong:
 lda old_kx,x
 sta rectx
 lda old_ky,x
 sta recty
 lda old_kw,x
 sta rectw
 lda old_kh,x
 sta recth
 jsr restore_rect
@restorenotice:
 ldx _back
 lda oldnotice,x
 beq @sprites
 lda #1
 sta kong_redraw
 lda #7
 sta rectx
 lda #68
 sta recty
 lda #18
 sta rectw
 lda #40
 sta recth
 jsr restore_rect
@sprites:
 ldx _back
 lda old_count,x
 clc
 adc oldoff_bank
 sta actor_index
@old:
 lda actor_index
 cmp oldoff_bank
 beq @restored
 dec actor_index
 ldx actor_index
 lda old_x,x
 sta rectx
 lda old_y,x
 sta recty
 lda old_w,x
 sta rectw
 lda old_h,x
 sta recth
 jsr check_overlap
 jsr restore_rect
 jmp @old
@restored:
 jsr draw_flowers
 lda #0
 sta actor_index
@actor:
 ldx actor_index
 cpx _draw_count
 beq @kong
 lda _draw_y,x
 sta recty
 lda _draw_x,x
 lsr
 lsr
 sta rectx
 lda _draw_id,x
 asl
 asl
 sta tmp
 lda _draw_x,x
 and #3
 ora tmp
 tax
 stx idx
 lda actor_restore_left,x
 clc
 adc rectx
 sta cx
 lda actor_restore_top,x
 clc
 adc recty
 sta cy
 ldx actor_index
 txa
 clc
 adc oldoff_bank
 tay
 lda cx
 sta old_x,y
 lda cy
 sta old_y,y
 ldx idx
 lda actor_restore_width,x
 sta old_w,y
 lda actor_restore_height,x
 sta old_h,y
 beq @nextactor
 sta recth
 lda actor_restore_width,x
 sta rectw
 jsr check_overlap
 jsr rect_address
 ldx idx
 lda actor_lo,x
 sta src
 lda actor_hi,x
 sta src+1
 lda actor_bank,x
 jsr asset_call
@nextactor:
 inc actor_index
 jmp @actor
@kong:
 jsr draw_kong
 ldx _back
 lda #0
 sta notice_old,x
 jsr _notice_draw
 lda _state
 cmp #3
 bne :+
 lda _layout
 cmp #2
 beq :+
 jsr draw_bonus
 ldx _back
 lda #1
 sta notice_old,x
:ldx _back
 lda notice_old,x
 sta oldnotice,x
@submit:
 jsr frame_descriptor
 ldx _back
 lda #0
 sta bg_dirty,x
 lda _draw_count
 sta old_count,x
 lda #1
 sta _pending
 jsr motion_restore
 ldx #1
@impact:
 lda _slife,x
 bpl :+
 lda #0
 sta _slife,x
:dex
 bpl @impact
 rts
draw_title:
 ldx _back
 lda bg_dirty,x
 bne :+
 rts
:lda #<title_rle
 sta src
 lda #>title_rle
 sta src+1
 lda #0
 sta dst
 lda page
 sta dst+1
@next:
 jsr @read
 tax
 beq @done
 jsr @read
 ldy #0
@run:
 sta (dst),y
 inc dst
 bne :+
 inc dst+1
:dex
 bne @run
 beq @next
@read:
 ldy #0
 lda (src),y
 inc src
 bne :+
 inc src+1
:rts
@done:rts
title_rle:.incbin "title.rle"
check_overlap:
 lda kong_redraw
 bne @done
 ldx _back
 lda recty
 cmp old_ky,x
 bcc @endtest
 sec
 sbc old_ky,x
 cmp old_kh,x
 bcs @done
 jmp @xtest
@endtest:
 clc
 adc recth
 cmp old_ky,x
 bcc @done
@xtest:
 lda rectx
 cmp old_kx,x
 bcc @xend
 sec
 sbc old_kx,x
 cmp old_kw,x
 bcs @done
 jmp @hit
@xend:
 clc
 adc rectw
 cmp old_kx,x
 bcc @done
@hit:
 lda #1
 sta kong_redraw
@done:rts
draw_kong:
 ldx _back
 lda _kong_frame
 sta old_pose,x
 lda _kong_dx
 sta old_dx,x
 lda #0
 sta old_kw,x
 lda _kong_frame
 jeq @done
 tay
 dey
 lda rom_kong_left,y
 clc
 adc #8
 sta rectx
 lda rom_kong_dx,y
 sta kong_dx_screen
 lda _kong_floor
 beq @position
 lda _kong_dx
 clc
 adc kong_dx_screen
 sta kong_dx_screen
 lda _kong_dx
 cmp #$80
 ror
 cmp #$80
 ror
 clc
 adc rectx
 sta rectx
@position:
 lda rectx
 sta old_kx,x
 lda _ky
 sta recty
 sta old_ky,x
 lda rom_kong_width,y
 sta asset_width
 sta old_kw,x
 lda rom_kong_height,y
 sta rows
 sta old_kh,x
 lda rom_kong_addr_lo,y
 sta src
 lda rom_kong_addr_hi,y
 sta src+1
 lda kong_redraw
 beq @done
 lda rom_kong_compiled_index,y
 bmi @raw
 tax
 lda kong_compiled_lo,x
 sta src
 lda kong_compiled_hi,x
 sta src+1
 lda kong_compiled_bank,x
 pha
 jsr rect_address
 pla
 jsr asset_compiled
 rts
@raw:
 lda rom_kong_bank,y
 pha
 jsr rect_address
 pla
 jsr asset_kong
@done:rts
; Exact flower art. Blank plots leave their surrounding static scenery intact.
draw_flowers:
 ldx _back
 lda flower_dirty,x
 bne :+
 rts
:lda #0
 sta flower_dirty,x
 lda #0
 sta actor_index
@flower:
 ldx actor_index
 lda _flower_x,x
 lsr
 lsr
 sta rectx
 lda #176
 sta recty
 jsr rect_address
 ldx actor_index
 lda _flower_x,x
 and #2
 beq @phase0
 lda #<(flower_pixels+48)
 ldy #>(flower_pixels+48)
 ldx #3
 bne @source
@phase0:
 lda #<flower_pixels
 ldy #>flower_pixels
 ldx #0
@source:
 sta src
 sty src+1
 lda flower_masks,x
 sta krow
 lda flower_masks+1,x
 sta krow+1
 lda flower_masks+2,x
 sta krow+2
 ldx actor_index
 lda _flower,x
 cmp #1
 beq :+
 lda #<flower_blank
 sta src
 lda #>flower_blank
 sta src+1
:lda #16
 sta rows
@row:
 ldy #2
@col:
 lda (dst),y
 and krow,y
 ora (src),y
 sta (dst),y
 dey
 bpl @col
 clc
 lda src
 adc #3
 sta src
 bcc :+
 inc src+1
:clc
 lda dst
 adc #32
 sta dst
 bcc :+
 inc dst+1
:dec rows
 bne @row
 inc actor_index
 lda actor_index
 cmp #5
 jne @flower
 rts
frame_descriptor:
 ldx _back
 lda _kong_frame
 sta pm_pose,x
 lda _ky
 clc
 adc #40
 sta pm_y,x
 lda kong_dx_screen
 clc
 adc #116
 sta pm_x,x
 lda _px
 clc
 adc #64
 sta pm_manx,x
 lda _py
 clc
 adc #40
 sta pm_many,x
 lda _walk
 and #1
 sta pm_manpose,x
 lda #0
 sta pm_cutscene,x
 sta pm_hide,x
 lda _kong_floor
 bne @cut
 lda _state
 cmp #3
 bne @notcut
 lda _layout
 cmp #2
 bne @notcut
@cut:
 lda #1
 sta pm_cutscene,x
@notcut:
 lda _py
 cmp #112
 bcc @hide
 cmp #200
 bcs @hide
 lda _invuln
 and #2
 beq @visible
@hide:
 lda #1
 sta pm_hide,x
@visible:
 lda _state
 bne :+
 lda #0
 sta pm_pose,x
 lda #1
 sta pm_hide,x
:lda oldnotice,x
 sta pm_notice,x
 lda #90
 sta pm_hx0,x
 lda #158
 sta pm_hx1,x
 lda #46
 sta pm_hy0,x
 sta pm_hy1,x
 lda _state
 cmp #2
 bne @livehive
 lda _hive_x
 clc
 adc #64
 sta pm_hx0,x
 lda _hive_x+1
 clc
 adc #64
 sta pm_hx1,x
 lda _hive_y
 clc
 adc #40
 sta pm_hy0,x
 lda _hive_y+1
 clc
 adc #40
 sta pm_hy1,x
 jmp @palette
@livehive:
 lda _layout
 cmp #2
 bne @palette
 lda _hive_bounce
 beq @palette
 lsr
 and #1
 beq :+
 lda #2
 bne :++
:lda #255
:ldy _hive_side
 cpy #1
 bne @righthive
 clc
 adc pm_hx0,x
 sta pm_hx0,x
 jmp @palette
@righthive:
 cpy #2
 bne @palette
 clc
 adc pm_hx1,x
 sta pm_hx1,x
@palette:
 lda _back
 beq :+
 lda #27
:sta paloff
 tax
 ldy #0
@palcopy:
 lda _pal0,y
 sta display_pal0,x
 lda _pal1,y
 sta display_pal1,x
 lda _pal2,y
 sta display_pal2,x
 inx
 iny
 cpy #27
 bne @palcopy
 lda _state
 beq @hud
 ldx _back
 lda pm_pose,x
 beq @hud
 tay
 dey
 lda rom_kong_height,y
 clc
 adc _ky
 sec
 sbc #1
 lsr
 lsr
 lsr
 clc
 adc #3
 adc paloff
 sta rows
 lda _ky
 lsr
 lsr
 lsr
 clc
 adc #2
 adc paloff
 tax
@kongpal:
 cpx rows
 bcs @hivepal
 lda fur_color
 sta display_pal1,x
 lda #$0e
 sta display_pal2,x
 inx
 bne @kongpal
@hivepal:
 lda rom_kong_hcount,y
 beq @hud
 lda rom_kong_hy,y
 clc
 adc _ky
 lsr
 lsr
 lsr
 clc
 adc #2
 adc paloff
 tax
 lda #3
 sta rows
@hp:
 lda hive_color
 sta display_pal0,x
 inx
 dec rows
 bne @hp
@hud:
 lda #<hud0
 sta dst
 lda #>hud0
 sta dst+1
 lda _back
 beq :+
 clc
 lda dst
 adc #64
 sta dst
 bcc :+
 inc dst+1
:ldy #63
@hudcopy:
 lda hudwork,y
 sta (dst),y
 dey
 bpl @hudcopy
 rts
update_pm:
 ; Remove only footprints from the last committed frame.
 ldx pm_prev_y
 ldy pm_prev_h
 beq @oldman
 lda #0
@clearbody:
 sta $0400,x
 sta $0500,x
 sta $0600,x
 inx
 dey
 bne @clearbody
@oldman:
 ldx pm_prev_man
 beq @oldhives
 ldy #16
 lda #0
@clearman:
 sta $0400,x
 sta $0500,x
 sta $0600,x
 sta $0700,x
 inx
 dey
 bne @clearman
@oldhives:
 ldx pm_prev_h0
 ldy #16
 lda #0
@clearleft:
 sta $0700,x
 inx
 dey
 bne @clearleft
 ldx pm_prev_h1
 ldy #16
@clearright:
 sta $0300,x
 inx
 dey
 bne @clearright
 ldx _front
 lda pm_hy0,x
 sta pm_prev_h0
 lda pm_hy1,x
 sta pm_prev_h1
 lda _state
 beq @hide_hives
 lda pm_hy0,x
 tax
 ldy #0
@left:
 lda hive_yellow_left,y
 sta $0700,x
 inx
 iny
 cpy #16
 bne @left
 ldx _front
 lda pm_hy1,x
 tax
 ldy #0
@right:
 lda hive_yellow_right,y
 sta $0300,x
 inx
 iny
 cpy #16
 bne @right
@hide_hives:
 ldx _front
 lda pm_hx1,x
 sta $c004
 clc
 adc #2
 sta $c005
 adc #2
 sta $c006
 adc #2
 sta $c007
 lda #$1c
 sta $c019
 lda #0
 sta pm_prev_h
 sta pm_prev_man
 ldx _front
 lda pm_pose,x
 beq @man
 tay
 dey
 lda rom_kong_height,y
 sta pm_height
 sta pm_prev_h
 lda pm_y,x
 sta nmi_index
 sta pm_prev_y
 lda rom_kong_pmaddr_lo,y
 sta nptr
 lda rom_kong_pmaddr_hi,y
 sta nptr+1
 clc
 lda nptr
 adc pm_height
 sta nptr1
 lda nptr+1
 adc #0
 sta nptr1+1
 clc
 lda nptr1
 adc pm_height
 sta nptr2
 lda nptr1+1
 adc #0
 sta nptr2+1
 lda rom_kong_pmbank,y
 jsr pm_copy_asset
@man:
 ldx _front
 lda pm_cutscene,x
 bne @hives
 lda pm_hide,x
 bne @hives
 lda pm_manpose,x
 beq :+
 lda #64
:clc
 adc #<(_pm_art+128)
 sta nptr
 lda #>(_pm_art+128)
 adc #0
 sta nptr+1
 lda pm_many,x
 sta pm_prev_man
 tax
 ldy #0
@manrow:
 lda (nptr),y
 sta $0400,x
 tya
 clc
 adc #16
 tay
 lda (nptr),y
 sta $0500,x
 tya
 adc #16
 tay
 lda (nptr),y
 sta $0600,x
 tya
 adc #16
 tay
 lda (nptr),y
 sta $0700,x
 tya
 sec
 sbc #47
 tay
 inx
 cpy #16
 bne @manrow
@hives:
 ldx _front
 lda pm_notice,x
 beq @done
 ldx #108
 lda #0
@occlude:
 sta $0400,x
 sta $0500,x
 sta $0600,x
 sta $0700,x
 inx
 cpx #148
 bne @occlude
@done:rts
hive_yellow_left:
 .byte 24,60,12,126,14,127,7,127,7,127,71,70,126,12,60,24
hive_yellow_right:
 .byte 36,60,48,189,176,253,208,253,208,253,209,145,189,48,60,36
.segment "COMMON"
rowlo:.repeat 192,I
 .byte <(I*32)
.endrepeat
rowhi:.repeat 192,I
 .byte >(I*32)
.endrepeat

.segment "CODE"
flower_masks: .byte 0,0,255,240,0,15
flower_pixels:
 .byte 0,0,0
 .byte 10,128,0
 .byte 42,160,0
 .byte 43,160,0
 .byte 42,160,0
 .byte 10,128,0
 .byte 1,80,0
 .byte 1,80,0
 .byte 21,0,0
 .byte 21,0,0
 .byte 1,0,0
 .byte 1,0,0
 .byte 1,0,0
 .byte 63,252,0
 .byte 63,252,0
 .byte 0,0,0
 .byte 0,0,0
 .byte 0,168,0
 .byte 2,170,0
 .byte 2,186,0
 .byte 2,170,0
 .byte 0,168,0
 .byte 0,21,0
 .byte 0,21,0
 .byte 1,80,0
 .byte 1,80,0
 .byte 0,16,0
 .byte 0,16,0
 .byte 0,16,0
 .byte 3,255,192
 .byte 3,255,192
 .byte 0,0,0
flower_blank: .res 48,0
