from pathlib import Path
import sys,re,json,struct
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'));B=R/'build';P=B/'port'
# Exact native scenery, represented as deduplicated 32-byte rows. This is
# immutable cartridge data; flowers and notices are composited separately.
leaf=[0]*16+[1,1,2,2,3,4,5,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34]
hive=bytes([2,128,10,160,15,160,42,168,63,168,42,170,63,234,42,170,63,234,42,170,44,42,44,40,42,168,15,160,10,160,2,128])
images=[]
for layout in range(3):
 for ready in range(2):
  for tops in range(2):
   a=bytearray(6144)
   def pixel(x,y,c):
    assert 0<=x<128 and 0<=y<192,(x,y)
    off=y*32+x//4;sh=6-(x%4)*2;a[off]=(a[off]&~(3<<sh))|(c<<sh)
   def box(x,y,w,h,c):
    for yy in range(y,y+h):
     for xx in range(x,x+w):pixel(xx,yy,c)
   def drawhive(x,y):
    for yy in range(16):
     for xx in range(8):pixel(x+2+xx,y+yy,(hive[yy*2+xx//4]>>(6-(xx%4)*2))&3)
   def platform(x,y,w):
    box(x,y,w,6,1)
    for xx in range(x+1,x+w-6,8):box(xx,y+1,6,3,0)
    box(x+2,y+6,2,12 if y==174 else 14,1);box(x+w-4,y+6,2,12 if y==174 else 14,1)
    if layout!=2:
     for n in range(18 if y==174 else 20):
      b=n>>2
      if x>b and (w!=40 or x==14):box(x-b-1,y+n,b+2,1,1)
      if x+w+b<128 and (w!=40 or x==74):box(x+w-1,y+n,b+2,1,1)
   for n in range(23):pixel(30+n,(22-n)//4,3 if ready else 1);pixel(97-n,(22-n)//4,3 if ready else 1)
   box(56,8,1,119,1);box(71,8,1,119,1)
   for n in range(20,118,12):box(55,n,3,2,1);box(70,n+4,3,2,1)
   if layout==2:
    box(8,70,1,122,1);box(119,70,1,122,1)
    for n in range(76,107,10):box(8,n,112,1,1);box(5,n-3,7,3,1);box(116,n-3,7,3,1)
   else:
    for f in range(3):
     for xx in range(38-f*6):
      yy=28+f*30+leaf[xx+f*6];length=7+(7 if xx&1 else 0)
      if xx>=34-f*6:length=38-f*6-xx
      box(xx,yy,1,length,1);box(127-xx,yy,1,length,1)
    box(37,62,1,72,1);box(90,62,1,72,1)
   if layout==2:drawhive(58,0)
   if layout==2 or tops:
    for yy in range(2,7):
     for xx in range(1,6):
      c=(0 if yy in (2,6) else 1) if xx in (1,5) else 1 if yy in (2,6) else 3
      if c:pixel(53+xx,yy,c);pixel(68+xx,yy,c)
   platform(8 if layout==2 else 1,174,112 if layout==2 else 126)
   if layout==0:platform(14,154,100);platform(28,134,72)
   if layout==1:platform(14,154,40);platform(74,154,40);platform(28,134,72)
   if layout==2:platform(28,154,72)
   if not ready and layout!=2:drawhive(24,6);drawhive(92,6)
   images.append(bytes(a))
# Yellow victory removes the upper attached hive.
a=bytearray(images[8]);
for y in range(16):a[y*32+14:y*32+18]=bytes(4)
a[4*32+14:4*32+18]=bytes([0x55]*4)
for y in range(4,14):a[y*32+14]|=0x40
images.append(bytes(a))
bg=bytearray();rowdict={};ptrs=[]
for img in images:
 pp=[]
 for y in range(192):
  row=img[y*32:(y+1)*32]
  if row not in rowdict:rowdict[row]=0x4000+len(bg);bg+=row
  pp.append(rowdict[row])
 ptrs.append(pp)
bgtables=[]
for pp in ptrs:
 bgtables.append(0x4000+len(bg));bg+=bytes(x&255 for x in pp)+bytes(x>>8 for x in pp)
# Feed the inherited exact actor generator and all 124 artwork poses through
# a 32 KB SuperCart allocator. Compiled actors are retained; Kong uses native
# compact pixels to avoid both XL RAM caches and duplicated machine code.
s=(R/'tools/cart_assets.py').read_text()
s=s.replace("R=Path(__file__).resolve().parents[1]", "R=ROOT")
s=s.replace('used=[1792]+[0]*15;limits=[8176]*16','used=[0,0,0,len(BG)];limits=[0,0x7800,0x7800,0x7800]\nrom[3*32768:3*32768+len(BG)]=BG')
s=s.replace('range(16)', 'range(4)') if False else s
s=s.replace('for bank in range(16):','for bank in range(1,4):').replace('addr=0xa000+used[bank];off=bank*8192+used[bank]','addr=0x4000+used[bank];off=bank*32768+used[bank]')
s=re.sub(r'COMPILED=\{[^\n]+\}', 'COMPILED={8,11,24,13,14,15,22,23,21,12,17,19,25,26}',s)
s=s.replace("if i==44:actors.append((128,0))", "if False:actors.append((128,0))")
s=s.replace('pos=bank*8192+(addr-0xa000)', 'pos=bank*32768+(addr-0x4000)')
s=s[:s.index('# A common footer must')]+s[s.index("out=['; Generated"):]
s=s.replace("print('Prepared ROM assets',sum(used)-1792", "print('Prepared ROM assets',sum(used)")
ns={'__file__':str(R/'tools/cart_assets.py'),'ROOT':R,'BG':bg};exec(compile(s,'cart_assets.py','exec'),ns)
tables=(R/'src/cart_tables.inc').read_text().replace('.segment "KTILES"','.segment "CODE"')
tables+='\nbg_lo: .byte '+','.join(str(x&255) for x in bgtables)+'\nbg_hi: .byte '+','.join(str(x>>8) for x in bgtables)+'\n'
(P/'tables.inc').write_text(tables)
(B/'backgrounds.bin').write_bytes(b''.join(images))
print('Background dictionary:',len(bg),'bytes;',len(rowdict),'unique rows')
